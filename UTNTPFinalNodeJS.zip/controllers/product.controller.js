class ProductController {

}

const product_controller = new ProductController

export default product_controller